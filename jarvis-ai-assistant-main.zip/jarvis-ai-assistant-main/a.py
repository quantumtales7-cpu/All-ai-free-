num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))
d = num1 + num2
print("The sum of", num1, "and", num2, "is", d)